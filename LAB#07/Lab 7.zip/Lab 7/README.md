# Lab 7 — SQL Filters: Assessment Problem (Online Bookstore)

**Course:** Database Systems
**Table used:** `Book` (database: `bookstore_lab`)

## Contents
- `RollNo_Filters.sql` — full setup script (CREATE DATABASE, CREATE TABLE, INSERT) followed by all
  10 graded assessment answers (**Q1–Q10**), each labelled with a `-- Qn` comment and its mark value.

## How to run
1. Open MySQL Workbench or the MySQL Command Line Client (MySQL 8.x).
2. Run the entire file, or run the setup block first, then each question individually to inspect
   its output.

```
SOURCE RollNo_Filters.sql;
```

## Marks breakdown
| Question | Marks |
|---|---|
| Q1 | 5 |
| Q2 | 10 |
| Q3 | 10 |
| Q4 | 10 |
| Q5 | 10 |
| Q6 | 5 |
| Q7 | 10 |
| Q8 | 15 |
| Q9 | 10 |
| Q10 | 15 |
| **Total** | **100** |

## Notes
- All 10 queries were verified against the exact 15-row dataset given in the lab manual before
  submission (e.g. Q6 correctly returns "Mystery Title" as the only book with no recorded author,
  Q9 correctly returns the 2 Urdu-language books sorted by year).
- Rename `RollNo_Filters.sql` to your actual roll number before pushing, e.g. `21B-0512-CS_Filters.sql`.
- Push this file to your GitHub repository inside a folder named `Lab7-Filters-Assessment/` (or as
  instructed by your instructor).
