# Lab #4 — Aggregate Functions, GROUP BY, HAVING

**Course:** Database Systems
**Topic:** COUNT, SUM, AVG, MIN, MAX · GROUP BY · HAVING · Aggregates with JOINs

## Contents

```
Lab4-Aggregates/
├── RollNo_Aggregates.sql   ← single deliverable file (rename RollNo → your roll number)
└── README.md               ← this file
```

## What's inside `RollNo_Aggregates.sql`

The file is organized top-to-bottom exactly in the order you should run it:

| Section | Contents |
|---|---|
| 0 | Setup script for the `agg_lab` (RetailStore) database — `Customer`, `Product`, `OrderItem` |
| 1 | **Lab Task Part A** — Tasks A1–A10 (whole-table aggregates, `COUNT` variations) |
| 2 | **Lab Task Part B** — Tasks B1–B17 (`GROUP BY`, `HAVING`, aggregates with `JOIN`) |
| 3 | Setup script for the `uni_lab` (University) database — `Student`, `Course`, `Enrollment` |
| 4 | **Assessment Problem** — Q1–Q12 (graded questions) |

Every answer is preceded by a labeled comment (`-- Task A1`, `-- Task B7`, `-- Q9`, etc.) so each query is easy to locate and grade, per the manual's requirement.

## How to run it

1. Open MySQL Workbench or the MySQL Command Line Client (MySQL 8.x).
2. Run the file top-to-bottom:
   ```
   mysql -u root -p < RollNo_Aggregates.sql
   ```
   or open it in Workbench and execute the whole script (⚡ "Execute (All)").
3. The script creates both `agg_lab` and `uni_lab` databases itself (`CREATE DATABASE IF NOT EXISTS ...`), so no manual setup is needed beforehand.
4. Because the script contains `SELECT` statements for every task, run it query-by-query (or one block at a time) if you want to see each result individually — running the whole file at once in the CLI will simply stream all result sets in order.

## Verification

Every query was checked for correctness before submission:

- **Join direction** — `LEFT JOIN` is used everywhere the task explicitly asks to include zero-activity rows (customers with no orders, products never sold, students with no enrollments); plain `JOIN` is used everywhere revenue/marks must be based on actual matching rows only.
- **`WHERE` vs `HAVING`** — row-level conditions (`StockQty > 0`, `City IS NOT NULL`, `YEAR(OrderDate) = 2024`) are placed in `WHERE`; conditions on an aggregate (`COUNT(*) > 1`, `AVG(Price) > 5000`, `SUM(...) > 50000`) are placed in `HAVING`.
- **Golden Rule of GROUP BY** — every non-aggregated column in each `SELECT` list also appears in the matching `GROUP BY` clause.
- **NULL handling** — `COUNT(*)` vs `COUNT(col)` vs `COUNT(DISTINCT col)` are each used exactly where the task calls for them (e.g. A5/A6 use `COUNT(DISTINCT ...)`, A7 contrasts `COUNT(*)` and `COUNT(City)`).
- **Logic cross-check** — the full query set was executed against an equivalent in-memory database loaded with the manual's exact sample data, confirming row counts and totals are internally consistent (e.g. the yearly revenue split in Task B16 sums to the same total revenue as Task A9; `LEFT JOIN` tasks correctly keep Maira Javed / Areeba Yasin as zero-count rows rather than dropping them).

## Before submitting

- [ ] Rename `RollNo_Aggregates.sql` to `<YourActualRollNumber>_Aggregates.sql`
- [ ] Push the renamed file to your GitHub repository, inside a folder named `Lab4-Aggregates/`
- [ ] Share the GitHub link to that folder before the deadline announced in class
