-- ============================================================
-- DATABASE SYSTEMS | LAB - DATABASE KEYS, TABLE COMMANDS & CRUD
-- Student: RollNo (replace with your actual roll number)
-- Database: university_lab
-- Based on: MySQL Lab Guide for Students
--   Section 1 - Database Keys
--   Section 2 - Table Commands
--   Section 3 - CRUD Operations
--   Section 4 - Other Table Operations (TRUNCATE / DROP)
--   Section 5 - Complete University Lab Example
--   Lab Tasks for Students (8 tasks)
-- ============================================================
-- Run this entire script top to bottom in MySQL 8.x
-- (MySQL Workbench or the Command Line Client).
-- It is fully idempotent -- safe to re-run from scratch.
-- ============================================================


-- ============================================================
-- SECTION 0: DATABASE SETUP
-- ============================================================
CREATE DATABASE IF NOT EXISTS university_lab;
USE university_lab;

-- Drop in child-to-parent order so foreign keys never block a DROP.
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS instructors;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS students_demo;
DROP TABLE IF EXISTS citizens_demo;


-- ============================================================
-- LAB TASK 1: Create the above tables with constraints
-- (Section 5 - Complete University Lab Example)
-- ============================================================

-- Departments: dept_name is UNIQUE (a natural candidate/alternate key,
-- even though dept_id -- a surrogate key -- was chosen as the PRIMARY KEY)
CREATE TABLE departments (
    dept_id    INT PRIMARY KEY,
    dept_name  VARCHAR(100) UNIQUE
);

-- Students: student_id is a surrogate key (AUTO_INCREMENT PRIMARY KEY);
-- email is UNIQUE, making it an alternate key; dept_id is a FOREIGN KEY.
CREATE TABLE students (
    student_id  INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(100) UNIQUE,
    age         INT,
    dept_id     INT,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

-- Courses: course_id is the primary key; dept_id is a FOREIGN KEY.
CREATE TABLE courses (
    course_id    INT PRIMARY KEY,
    course_name  VARCHAR(100),
    dept_id      INT,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

-- Instructors: email is UNIQUE; dept_id is a FOREIGN KEY.
CREATE TABLE instructors (
    instructor_id  INT PRIMARY KEY,
    name           VARCHAR(100),
    email          VARCHAR(100) UNIQUE,
    dept_id        INT,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

-- Enrollments: a junction table linking Students and Courses.
-- (student_id, course_id) together form a COMPOSITE PRIMARY KEY --
-- a student may enroll in many courses and a course may have many
-- students, but the same student cannot enroll in the same course twice.
CREATE TABLE enrollments (
    student_id  INT,
    course_id   INT,
    semester    VARCHAR(20),
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id)  REFERENCES courses(course_id)
);


-- ============================================================
-- LAB TASK 2: Insert data and query using SELECT
-- ============================================================

-- ---- INSERT ----
INSERT INTO departments VALUES (1, 'CS'), (2, 'EE');

INSERT INTO students (name, email, age, dept_id) VALUES
('Ali', 'ali@gmail.com', 20, 1),
('Sara', 'sara@gmail.com', 21, 1),
('Ahmed', 'ahmed@gmail.com', 22, 2);
-- Fresh AUTO_INCREMENT -> Ali = 1, Sara = 2, Ahmed = 3

INSERT INTO courses VALUES
(101, 'Database', 1),
(102, 'AI', 1),
(201, 'Circuits', 2);

-- Optional but included for a fully populated, self-contained schema
INSERT INTO instructors VALUES
(1, 'Dr. Imran Shah', 'imran@example.edu', 1),
(2, 'Dr. Nadia Farooq', 'nadia@example.edu', 2);

INSERT INTO enrollments VALUES
(1, 101, 'Fall 2025'),
(1, 102, 'Fall 2025'),
(2, 101, 'Fall 2025');

-- ---- SELECT ----
SELECT * FROM students;

SELECT name, email
FROM students
WHERE dept_id = 1;

SELECT course_id, course_name
FROM courses
ORDER BY course_name;

SELECT * FROM enrollments;


-- ============================================================
-- LAB TASK 3: Update a student's name
-- ============================================================
UPDATE students
SET name = 'Ali Khan'
WHERE student_id = 1;

SELECT student_id, name FROM students WHERE student_id = 1; -- verify: 'Ali Khan'


-- ============================================================
-- LAB TASK 4: Delete a student record
-- ============================================================
-- Ahmed (student_id = 3) has no rows in 'enrollments', so removing him
-- will not violate the enrollments foreign key constraint.
-- (Deleting Ali or Sara here instead would fail with an FK error,
-- since both appear in 'enrollments' -- they would need to be
-- removed from enrollments first.)
DELETE FROM students
WHERE student_id = 3;

SELECT * FROM students; -- verify: only Ali Khan (1) and Sara (2) remain


-- ============================================================
-- LAB TASK 5: Try TRUNCATE and DROP
-- ============================================================
-- Demonstrated on a standalone practice table rather than the real
-- 'students' table: 'students' is referenced by the 'enrollments'
-- foreign key, so TRUNCATE TABLE students / DROP TABLE students would
-- fail with a foreign-key constraint error, and would also destroy the
-- data the join task below (Task 7) needs. 'students_demo' has no
-- foreign-key relationships, so both commands run cleanly here.

CREATE TABLE students_demo (
    student_id  INT PRIMARY KEY,
    name        VARCHAR(100),
    email       VARCHAR(100)
);

INSERT INTO students_demo VALUES (1, 'Demo Student', 'demo@example.com');

SELECT * FROM students_demo;   -- 1 row

TRUNCATE TABLE students_demo;  -- removes all rows, keeps the table structure
SELECT * FROM students_demo;   -- 0 rows, but the table still exists

DROP TABLE students_demo;      -- removes the table definition entirely
-- SELECT * FROM students_demo;  -- would now error: table doesn't exist (expected)


-- ============================================================
-- LAB TASK 6: Add a new column using ALTER TABLE
-- ============================================================
ALTER TABLE students
ADD phone VARCHAR(20);

SELECT student_id, name, phone FROM students; -- phone is NULL for existing rows

-- Populate it for the demo so later selects have real values
UPDATE students SET phone = '0300-1112233' WHERE student_id = 1;
UPDATE students SET phone = '0301-4445566' WHERE student_id = 2;


-- ============================================================
-- LAB TASK 7: Practice joins between Students and Courses
-- ============================================================
-- Students and Courses have no direct foreign key between them --
-- they are related through the 'enrollments' junction table, so the
-- join passes through it.

-- INNER JOIN: only students who are actually enrolled in a course
SELECT s.student_id,
       s.name,
       c.course_name,
       e.semester
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN courses c      ON e.course_id  = c.course_id
ORDER BY s.student_id;

-- LEFT JOIN: every student, including those with no enrollments
SELECT s.student_id,
       s.name,
       c.course_name
FROM students s
LEFT JOIN enrollments e ON s.student_id = e.student_id
LEFT JOIN courses c      ON e.course_id  = c.course_id
ORDER BY s.student_id;


-- ============================================================
-- LAB TASK 8: Explore candidate keys, alternate keys, and composite keys
-- (Section 1 - Database Keys, mapped onto the schema above)
-- ============================================================

-- PRIMARY KEY
--   departments.dept_id, students.student_id, courses.course_id,
--   instructors.instructor_id, and (student_id, course_id) in enrollments.

-- FOREIGN KEY
--   students.dept_id -> departments.dept_id
--   courses.dept_id -> departments.dept_id
--   instructors.dept_id -> departments.dept_id
--   enrollments.student_id -> students.student_id
--   enrollments.course_id -> courses.course_id

-- UNIQUE KEY
--   students.email, departments.dept_name, instructors.email

-- CANDIDATE KEY (in 'students')
--   {student_id} and {email} can each, on their own, uniquely identify
--   a row -- both are candidate keys.

-- ALTERNATE KEY (in 'students')
--   student_id was chosen as the PRIMARY KEY, so the remaining
--   candidate key, email, becomes the ALTERNATE KEY.
-- The UNIQUE constraint on email enforces this:
-- SELECT email, COUNT(*) FROM students GROUP BY email HAVING COUNT(*) > 1;
--   -> returns no rows, proving email values are unique.
-- The following insert would violate that alternate key and fail
-- (kept commented out so the script runs error-free):
-- INSERT INTO students (name, email, age, dept_id)
-- VALUES ('Duplicate Ali', 'ali@gmail.com', 25, 1);

-- SUPER KEY (in 'students', a few examples)
--   {student_id}, {email}, {student_id, name}, {email, age} are all
--   super keys -- any set of columns that includes a candidate key.

-- COMPOSITE KEY
--   enrollments(student_id, course_id) -- neither column alone is
--   unique in this table, but the pair together is.
SELECT student_id, course_id, COUNT(*) AS row_count
FROM enrollments
GROUP BY student_id, course_id
HAVING COUNT(*) > 1;
-- -> returns no rows, proving (student_id, course_id) pairs are unique.

-- NATURAL KEY vs SURROGATE KEY
--   students.student_id is a SURROGATE KEY: it is an artificial,
--   system-generated (AUTO_INCREMENT) identifier with no real-world
--   meaning. A NATURAL KEY, by contrast, is a real-world unique
--   attribute used directly as the primary key -- demonstrated below
--   with a standalone table, exactly as in the lab guide.
CREATE TABLE citizens_demo (
    cnic  VARCHAR(15) PRIMARY KEY,
    name  VARCHAR(100)
);

INSERT INTO citizens_demo VALUES ('35202-1234567-1', 'Bilal Hassan');

SELECT * FROM citizens_demo;

DROP TABLE citizens_demo; -- clean up the standalone demo table


-- ============================================================
-- End of Lab -- Database Keys, Table Commands & CRUD Operations
-- ============================================================
