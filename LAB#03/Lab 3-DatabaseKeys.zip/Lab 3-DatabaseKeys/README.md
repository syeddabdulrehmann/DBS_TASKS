# Lab — Database Keys, Table Commands & CRUD Operations

**Course:** Database Systems
**Topic:** Primary/Foreign/Unique/Composite/Candidate/Alternate/Super/Natural/Surrogate keys; `CREATE`/`ALTER` table commands; CRUD (`INSERT`/`SELECT`/`UPDATE`/`DELETE`); `TRUNCATE`/`DROP`; joins
**Tools:** MySQL 8.x, MySQL Workbench / Command Line Client
**Source:** *MySQL Lab Guide for Students* (Sections 1–5 + the 8 "Lab Tasks for Students")

## Contents

- `RollNo_Lab_DatabaseKeys_CRUD.sql` — one self-contained, idempotent script covering the full `university_lab` database (`departments`, `students`, `courses`, `instructors`, `enrollments`) and all 8 assigned lab tasks, each labelled with a `-- LAB TASK N` comment:

| Task | What it does |
|---|---|
| 1 | Creates all 5 tables with primary/foreign/unique/composite key constraints |
| 2 | Inserts the sample data and runs several `SELECT` queries |
| 3 | Updates a student's name (`Ali` → `Ali Khan`) |
| 4 | Deletes a student record (Ahmed — chosen because he has no enrollments, so the delete doesn't violate the `enrollments` foreign key) |
| 5 | Demonstrates `TRUNCATE` and `DROP` on a standalone `students_demo` table (see note below) |
| 6 | Adds a `phone` column to `students` via `ALTER TABLE` |
| 7 | Joins `students` → `enrollments` → `courses` (both `INNER JOIN` and `LEFT JOIN` versions) |
| 8 | Maps every key type from the guide onto the real schema, with verification queries for the composite key (`enrollments`) and the alternate key (`students.email`), plus a natural-key demo (`citizens_demo`) |

## Why Task 5 uses a separate table

`students` is referenced by the `enrollments` foreign key, so running `TRUNCATE TABLE students` or `DROP TABLE students` directly would fail with a foreign-key constraint error — and would also delete the data Task 7's join needs. The script instead creates a small standalone `students_demo` table with no foreign keys, so `TRUNCATE` and `DROP` both run cleanly, exactly as written in the lab guide.

## How to run

1. Open the `.sql` file in MySQL Workbench or the MySQL CLI.
2. Rename the file to replace `RollNo` with your actual roll number.
3. Execute the whole script — it creates the `university_lab` database and every table, then runs each lab task in order. It is safe to re-run from scratch at any time.

## Submission

Push this folder to your GitHub repository, containing the renamed `.sql` file.
