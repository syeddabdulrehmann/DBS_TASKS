-- =====================================================================
-- DATABASE SYSTEMS | LAB TASKS SOLUTION
-- Topic     : Database Normalization (1NF -> 2NF -> 3NF)
-- Scenario  : Online Bookstore Orders (Section 7 of the Lab Manual)
-- Student   : RollNo_YourName   (rename this file before submitting)
-- Folder    : Lab-Normalization/
-- =====================================================================

DROP DATABASE IF EXISTS bookstore_lab;
CREATE DATABASE bookstore_lab;
USE bookstore_lab;

-- =====================================================================
-- TASK 1 — Functional Dependencies & Anomalies
-- =====================================================================
-- Raw (unnormalized) columns:
--   OrderID, OrderDate, CustID, CustName, CustEmail,
--   BookID, BookTitle, Publisher, UnitPrice, Qty
--
-- Functional Dependencies (FDs) identified:
--   OrderID              -> OrderDate, CustID
--   CustID               -> CustName, CustEmail
--   BookID               -> BookTitle, Publisher, UnitPrice
--   (OrderID, BookID)    -> Qty
--
-- Candidate key of the raw relation: (OrderID, BookID)
-- (an order can contain several books, so only the pair uniquely
--  identifies one purchased line item)
--
-- Anomalies present in the flat (unnormalized) table:
--   INSERTION : A new book title cannot be added to the catalogue
--               (e.g. a new Pearson title not yet ordered) until a
--               customer actually places an order for it, because
--               BookTitle/Publisher/UnitPrice only exist as part of
--               an order row.
--   UPDATE    : If customer Bilal's email changes, every order row
--               belonging to Bilal (O-501 and O-503) must be updated,
--               or the data becomes inconsistent.
--   DELETION  : If Areeba's only order (O-502) is deleted/cancelled,
--               her customer record (CustID C-12, name, email) is
--               lost entirely from the database.

-- =====================================================================
-- TASK 2 — First Normal Form (1NF)
-- =====================================================================
-- Rule: atomic values only, no repeating groups, uniquely identifiable rows.
-- The multi-valued "Book Title (BookID)" / "Publisher" / "Unit Price" /
-- "Qty" cells from Table 7.1 are split so each order+book combination
-- becomes its own row.
-- Primary key: (OrderID, BookID)

CREATE TABLE OrderBook_1NF (
    OrderID     VARCHAR(10),
    OrderDate   DATE,
    CustID      VARCHAR(10),
    CustName    VARCHAR(50),
    CustEmail   VARCHAR(50),
    BookID      VARCHAR(10),
    BookTitle   VARCHAR(50),
    Publisher   VARCHAR(50),
    UnitPrice   DECIMAL(10,2),
    Qty         INT,
    PRIMARY KEY (OrderID, BookID)
);

INSERT INTO OrderBook_1NF VALUES
('O-501','2026-04-02','C-11','Bilal','bilal@x.com','B-1','SQL Basics','Pearson',1200,1),
('O-501','2026-04-02','C-11','Bilal','bilal@x.com','B-2','Python 101','OReilly',1500,2),
('O-502','2026-04-03','C-12','Areeba','areeba@x.com','B-1','SQL Basics','Pearson',1200,3),
('O-503','2026-04-05','C-11','Bilal','bilal@x.com','B-3','Networks','Pearson',1800,1),
('O-503','2026-04-05','C-11','Bilal','bilal@x.com','B-2','Python 101','OReilly',1500,1);

-- Still broken: OrderDate/CustName/CustEmail repeat for every book in the
-- same order, and BookTitle/Publisher/UnitPrice repeat for every order
-- that includes the same book. Redundancy remains -> proceed to 2NF.

-- =====================================================================
-- TASK 3 — Second Normal Form (2NF)
-- =====================================================================
-- Rule: table is in 1NF and every non-prime attribute depends on the
-- WHOLE composite key (OrderID, BookID) — no partial dependencies.
--
-- Partial-dependency check against the composite key (OrderID, BookID):
--   OrderDate, CustID, CustName, CustEmail  -> depend on OrderID ALONE
--        => PARTIAL DEPENDENCY -> extract to an order-level table
--   BookTitle, Publisher, UnitPrice         -> depend on BookID ALONE
--        => PARTIAL DEPENDENCY -> extract to a book-level table
--   Qty                                     -> depends on the FULL key
--        => full dependency -> stays in the order-line table

DROP TABLE IF EXISTS OrderBook_1NF;

CREATE TABLE Orders_2NF (
    OrderID     VARCHAR(10) PRIMARY KEY,
    OrderDate   DATE,
    CustID      VARCHAR(10),
    CustName    VARCHAR(50),
    CustEmail   VARCHAR(50)
);

CREATE TABLE Book_2NF (
    BookID      VARCHAR(10) PRIMARY KEY,
    BookTitle   VARCHAR(50),
    Publisher   VARCHAR(50),
    UnitPrice   DECIMAL(10,2)
);

CREATE TABLE OrderLine (
    OrderID     VARCHAR(10),
    BookID      VARCHAR(10),
    Qty         INT,
    PRIMARY KEY (OrderID, BookID),
    FOREIGN KEY (OrderID) REFERENCES Orders_2NF(OrderID),
    FOREIGN KEY (BookID)  REFERENCES Book_2NF(BookID)
);

-- Progress, but not fully done: inside Orders_2NF, CustID determines
-- CustName and CustEmail (CustID -> CustName, CustEmail). Since
-- OrderID -> CustID -> CustName/CustEmail, this is a TRANSITIVE
-- dependency of CustName/CustEmail on the key OrderID. 3NF will fix it.
--
-- Book_2NF, on the other hand, has no such chain: BookTitle, Publisher
-- and UnitPrice all depend directly on BookID and not on each other,
-- so Book_2NF already satisfies 3NF as-is.

-- =====================================================================
-- TASK 4 — Third Normal Form (3NF)
-- =====================================================================
-- Rule: table is in 2NF and no non-prime attribute is transitively
-- dependent on the primary key.
--
-- Transitive dependency found: OrderID -> CustID -> CustName, CustEmail
-- Fix: extract customer data into its own Customer table, keyed on CustID.
--
-- Book_2NF has no transitive dependency (Publisher is a plain value with
-- no further attributes hanging off it in this dataset), so per the
-- "avoid over-normalizing small lookups" guidance it is kept as-is and
-- simply renamed to Book.

DROP TABLE IF EXISTS OrderLine;
DROP TABLE IF EXISTS Orders_2NF;
DROP TABLE IF EXISTS Book_2NF;

CREATE TABLE Customer (
    CustID      VARCHAR(10) PRIMARY KEY,
    CustName    VARCHAR(50),
    CustEmail   VARCHAR(50)
);

CREATE TABLE Orders (
    OrderID     VARCHAR(10) PRIMARY KEY,
    OrderDate   DATE,
    CustID      VARCHAR(10),
    FOREIGN KEY (CustID) REFERENCES Customer(CustID)
);

CREATE TABLE Book (
    BookID      VARCHAR(10) PRIMARY KEY,
    BookTitle   VARCHAR(50),
    Publisher   VARCHAR(50),
    UnitPrice   DECIMAL(10,2)
);

CREATE TABLE OrderLine (
    OrderID     VARCHAR(10),
    BookID      VARCHAR(10),
    Qty         INT,
    PRIMARY KEY (OrderID, BookID),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (BookID)  REFERENCES Book(BookID)
);

-- Populate the final 3NF schema
INSERT INTO Customer VALUES
('C-11','Bilal','bilal@x.com'),
('C-12','Areeba','areeba@x.com');

INSERT INTO Orders VALUES
('O-501','2026-04-02','C-11'),
('O-502','2026-04-03','C-12'),
('O-503','2026-04-05','C-11');

INSERT INTO Book VALUES
('B-1','SQL Basics','Pearson',1200),
('B-2','Python 101','OReilly',1500),
('B-3','Networks','Pearson',1800);

INSERT INTO OrderLine VALUES
('O-501','B-1',1),
('O-501','B-2',2),
('O-502','B-1',3),
('O-503','B-3',1),
('O-503','B-2',1);

-- =====================================================================
-- TASK 5 — Verification Queries
-- =====================================================================

-- (a) Reproduce the original report: one row per book purchased
SELECT
    o.OrderID,
    o.OrderDate,
    c.CustName,
    c.CustEmail,
    b.BookTitle,
    b.Publisher,
    b.UnitPrice,
    ol.Qty,
    (b.UnitPrice * ol.Qty) AS LineTotal
FROM OrderLine ol
JOIN Orders   o ON ol.OrderID = o.OrderID
JOIN Customer c ON o.CustID   = c.CustID
JOIN Book     b ON ol.BookID  = b.BookID
ORDER BY o.OrderID, b.BookTitle;

-- (b) Every customer's total spend
SELECT
    c.CustID,
    c.CustName,
    SUM(b.UnitPrice * ol.Qty) AS TotalSpend
FROM Customer c
JOIN Orders   o  ON c.CustID  = o.CustID
JOIN OrderLine ol ON o.OrderID = ol.OrderID
JOIN Book     b  ON ol.BookID  = b.BookID
GROUP BY c.CustID, c.CustName
ORDER BY TotalSpend DESC;

-- =====================================================================
-- TASK 6 — Reflection: how the 3NF schema prevents the Task-1 anomalies
-- =====================================================================
-- INSERTION anomaly solved: a new book (with its title, publisher and
--   price) can now be inserted directly into the Book table with no
--   order required, because Book no longer depends on OrderLine existing.
-- UPDATE anomaly solved: Bilal's email is stored exactly once, in the
--   single row CustID = 'C-11' of the Customer table, so changing it is
--   a single UPDATE statement instead of one per order.
-- DELETION anomaly solved: deleting Areeba's order O-502 (a row in
--   OrderLine/Orders) no longer removes her customer record, because
--   Customer is a separate table that does not depend on any order
--   existing.
-- Overall, every fact (customer info, book info, order info, line-item
-- quantity) is now stored in exactly one place, and foreign keys keep
-- the tables consistent with each other.
-- =====================================================================
-- End of Lab Tasks Solution (Bookstore Normalization)
-- =====================================================================
