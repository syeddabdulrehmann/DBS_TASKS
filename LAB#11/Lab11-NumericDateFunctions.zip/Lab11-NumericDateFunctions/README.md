# Lab 11 — Numeric & Date/Time Functions

**Course:** Database Systems
**Topic:** Scalar SQL numeric functions (`ROUND`, `CEIL`, `FLOOR`, `TRUNCATE`, `ABS`, `MOD`) and date/time functions (`NOW`, `CURDATE`, `YEAR`/`MONTH`/`DAY`, `DATEDIFF`, `DATE_ADD`, `DATE_FORMAT`, `TIMESTAMPDIFF`)
**Tools:** MySQL 8.x, MySQL Workbench / Command Line Client

## Contents

- `RollNo_Lab11_NumericDateFunctions.sql` — self-contained script:
  - Database/table setup (`scalar_lab.Customer`, `scalar_lab.Product`) with sample data
  - Solutions to Tasks B1–B15 (Part B — Numeric & Date/Time Functions), each labelled with a `-- Task BX` comment
- `RollNo_Lab11_Assessment_EmployeeDB.sql` — self-contained script:
  - Database/table setup (`emp_lab.Employee`) with sample data
  - Solutions to the 10 graded Assessment questions (Q1–Q10), each labelled with a `-- QX (marks)` comment

## How to run

1. Open each `.sql` file in MySQL Workbench or the MySQL CLI (they use separate databases, so either order works).
2. Rename both files to replace `RollNo` with your actual roll number.
3. Execute each script fully — it creates its database/table, then runs every query in order.

## Notes on Q10

`City` is `NULL` for one employee (Hira Yousaf), and `CONCAT()` with a `NULL` argument returns `NULL` in MySQL. `COALESCE(City, 'N/A')` is used so the `Profile` column is still produced for every row.

## Submission

Push this folder to your GitHub repository as `Lab11-NumericDateFunctions/`, containing both renamed `.sql` files.
