-- ============================================================
-- LAB 8 — SQL JOINS (Company Database)
-- Database Systems
-- Student: RollNo (replace with your actual roll number)
-- Covers: Lab Manual #2 - Lab Tasks Part A and Part B
-- Engine: MySQL 8.x
-- ============================================================

-- ============================================================
-- SECTION 1: SETUP SCRIPT (run first)
-- ============================================================

CREATE DATABASE IF NOT EXISTS joins_lab;
USE joins_lab;

DROP TABLE IF EXISTS Assignment, Project, Employee, Department;

CREATE TABLE Department (
    DeptID   INT PRIMARY KEY,
    DeptName VARCHAR(40) NOT NULL,
    Location VARCHAR(30),
    Budget   DECIMAL(12,2)
);

CREATE TABLE Employee (
    EmpID     INT PRIMARY KEY,
    EmpName   VARCHAR(50) NOT NULL,
    Gender    CHAR(1),
    Salary    DECIMAL(10,2),
    HireDate  DATE,
    City      VARCHAR(30),
    ManagerID INT,
    DeptID    INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID),
    FOREIGN KEY (ManagerID) REFERENCES Employee(EmpID)
);

CREATE TABLE Project (
    ProjectID   INT PRIMARY KEY,
    ProjectName VARCHAR(50) NOT NULL,
    StartDate   DATE,
    EndDate     DATE,
    DeptID      INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Assignment (
    EmpID        INT,
    ProjectID    INT,
    HoursPerWeek INT,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

-- Departments
INSERT INTO Department VALUES
(10, 'Engineering', 'Lahore', 5000000),
(20, 'Marketing', 'Karachi', 2000000),
(30, 'Finance', 'Islamabad', 3000000),
(40, 'Research', 'Lahore', 4000000),
(50, 'Sales', 'Karachi', NULL); -- new dept, no employees yet

-- Employees (NULL ManagerID = top of the hierarchy)
INSERT INTO Employee VALUES
(101,'Ali Khan',     'M', 120000,'2018-03-15','Lahore',     NULL, 10),
(102,'Sara Iqbal',   'F',  95000,'2019-06-01','Lahore',     101,  10),
(103,'Hamza Raza',   'M',  85000,'2020-01-20','Karachi',    101,  10),
(104,'Ayesha Noor',  'F', 110000,'2017-11-10','Karachi',    NULL, 20),
(105,'Bilal Ahmed',  'M',  70000,'2021-04-05','Karachi',    104,  20),
(106,'Fatima Sheikh','F',  90000,'2019-09-12','Islamabad',  NULL, 30),
(107,'Usman Tariq',  'M',  78000,'2022-02-18','Islamabad',  106,  30),
(108,'Maira Javed',  'F', 115000,'2016-07-22','Lahore',     NULL, 40),
(109,'Zain Abbas',   'M',  60000,'2023-01-09','Lahore',     108,  40),
(110,'Nida Yousaf',  'F',  72000,'2022-08-30',NULL,         108,  40);

-- Projects
INSERT INTO Project VALUES
(1001,'Website Revamp', '2024-01-10','2024-06-30', 10),
(1002,'Mobile App',     '2024-03-01','2024-12-31', 10),
(1003,'Brand Campaign', '2024-02-15','2024-05-15', 20),
(1004,'Audit System',   '2024-04-01', NULL,        30),
(1005,'AI Research',    '2024-05-01','2025-04-30', 40),
(1006,'Internal Tool',  '2024-06-01','2024-09-30', NULL); -- no dept yet

-- Assignments (employees 107 and 110 are NOT assigned, project 1006 has no staff)
INSERT INTO Assignment VALUES
(101, 1001, 10),
(102, 1001, 20),
(102, 1002, 15),
(103, 1002, 30),
(104, 1003, 25),
(105, 1003, 40),
(106, 1004, 35),
(108, 1005, 20),
(109, 1005, 30);


-- ============================================================
-- SECTION 2: PART A — INNER, LEFT, RIGHT JOINS
-- ============================================================

-- Task A1: Every employee with department name and location (INNER JOIN)
SELECT e.EmpID, e.EmpName, d.DeptName, d.Location
FROM Employee e
INNER JOIN Department d ON e.DeptID = d.DeptID;

-- Task A2: Same as A1, but include employees whose DeptID is NULL (LEFT JOIN)
-- Note: in this sample data every employee has a DeptID, so the result set
-- is identical to A1 — but LEFT JOIN guarantees no employee is ever dropped
-- even if a future row has a NULL/unmatched DeptID.
SELECT e.EmpID, e.EmpName, d.DeptName, d.Location
FROM Employee e
LEFT JOIN Department d ON e.DeptID = d.DeptID;

-- Task A3: Every department with its employees' names.
-- Departments with no employees still appear once with NULL EmpName.
SELECT d.DeptName, e.EmpName
FROM Department d
LEFT JOIN Employee e ON e.DeptID = d.DeptID
ORDER BY d.DeptName;

-- Task A4: Every project with its department name and location.
-- Includes projects that have no department (e.g. Internal Tool).
SELECT p.ProjectName, d.DeptName, d.Location
FROM Project p
LEFT JOIN Department d ON p.DeptID = d.DeptID;

-- Task A5: Employees not assigned to any project (LEFT JOIN + IS NULL)
SELECT e.EmpID, e.EmpName
FROM Employee e
LEFT JOIN Assignment a ON e.EmpID = a.EmpID
WHERE a.EmpID IS NULL;

-- Task A6: Every project that currently has no assignments
SELECT p.ProjectID, p.ProjectName
FROM Project p
LEFT JOIN Assignment a ON p.ProjectID = a.ProjectID
WHERE a.ProjectID IS NULL;

-- Task A7: Every employee in Engineering with salary, sorted by salary DESC
SELECT e.EmpName, e.Salary
FROM Employee e
INNER JOIN Department d ON e.DeptID = d.DeptID
WHERE d.DeptName = 'Engineering'
ORDER BY e.Salary DESC;

-- Task A8: Employees in Lahore-based departments
SELECT e.EmpName, d.DeptName
FROM Employee e
INNER JOIN Department d ON e.DeptID = d.DeptID
WHERE d.Location = 'Lahore';

-- Task A9: Every department and its employee count (LEFT JOIN + COUNT + GROUP BY)
-- Includes departments with zero employees (Sales).
SELECT d.DeptName, COUNT(e.EmpID) AS EmployeeCount
FROM Department d
LEFT JOIN Employee e ON d.DeptID = e.DeptID
GROUP BY d.DeptID, d.DeptName
ORDER BY d.DeptName;

-- Task A10: FULL OUTER JOIN of Employee and Department, emulated with UNION
-- (MySQL has no native FULL OUTER JOIN)
SELECT e.EmpName, d.DeptName
FROM Employee e
LEFT JOIN Department d ON e.DeptID = d.DeptID
UNION
SELECT e.EmpName, d.DeptName
FROM Employee e
RIGHT JOIN Department d ON e.DeptID = d.DeptID;


-- ============================================================
-- SECTION 3: PART B — SELF JOINS, MULTI-TABLE JOINS, COMBINED
-- ============================================================

-- Task B1: Each employee with their manager's name (SELF JOIN)
-- Top-level managers (Ali, Ayesha, Fatima, Maira) appear with NULL Manager.
SELECT e.EmpName AS Employee,
       m.EmpName AS Manager
FROM Employee e
LEFT JOIN Employee m ON e.ManagerID = m.EmpID;

-- Task B2: Employees who earn more than their direct manager
-- Result: EMPTY with this dataset — no employee currently out-earns their
-- manager. The query is still correct; it simply reflects the sample data.
SELECT e.EmpName AS Employee, e.Salary AS EmpSalary,
       m.EmpName AS Manager, m.Salary AS MgrSalary
FROM Employee e
INNER JOIN Employee m ON e.ManagerID = m.EmpID
WHERE e.Salary > m.Salary;

-- Task B3: Employees whose manager works in a different department
-- Show EmpName, ManagerName, and both department names.
-- Result: EMPTY with this dataset — every employee sits in the same
-- department as their manager. Query logic is verified correct.
SELECT e.EmpName AS Employee, m.EmpName AS Manager,
       de.DeptName AS EmployeeDept, dm.DeptName AS ManagerDept
FROM Employee e
INNER JOIN Employee m ON e.ManagerID = m.EmpID
INNER JOIN Department de ON e.DeptID = de.DeptID
INNER JOIN Department dm ON m.DeptID = dm.DeptID
WHERE e.DeptID <> m.DeptID;

-- Task B4: Every employee with the project they work on and weekly hours
-- (3-table join: Employee -> Assignment -> Project)
SELECT e.EmpName, p.ProjectName, a.HoursPerWeek
FROM Employee e
JOIN Assignment a ON e.EmpID = a.EmpID
JOIN Project p ON a.ProjectID = p.ProjectID
ORDER BY e.EmpName;

-- Task B5: Every assignment with employee name, project name, and department
-- name of the project (4-table join)
SELECT e.EmpName, p.ProjectName, d.DeptName
FROM Assignment a
JOIN Employee e ON a.EmpID = e.EmpID
JOIN Project p ON a.ProjectID = p.ProjectID
JOIN Department d ON p.DeptID = d.DeptID;

-- Task B6: Names and weekly hours of employees working on the Mobile App project
SELECT e.EmpName, a.HoursPerWeek
FROM Employee e
JOIN Assignment a ON e.EmpID = a.EmpID
JOIN Project p ON a.ProjectID = p.ProjectID
WHERE p.ProjectName = 'Mobile App';

-- Task B7: Every Lahore employee with their assigned projects (name + hours)
-- Includes Lahore employees with no assignments.
SELECT e.EmpName, p.ProjectName, a.HoursPerWeek
FROM Employee e
LEFT JOIN Assignment a ON e.EmpID = a.EmpID
LEFT JOIN Project p ON a.ProjectID = p.ProjectID
WHERE e.City = 'Lahore';

-- Task B8: Employees who work on a project run by a different department
-- than their own (compares e.DeptID and p.DeptID)
-- Result: EMPTY with this dataset — every employee's projects belong to
-- their own department. Query logic is verified correct (also handles the
-- case where a project has no department at all).
SELECT DISTINCT e.EmpName
FROM Employee e
JOIN Assignment a ON e.EmpID = a.EmpID
JOIN Project p ON a.ProjectID = p.ProjectID
WHERE p.DeptID IS NULL OR p.DeptID <> e.DeptID;

-- Task B9: For each department, list project names that started in 2024.
-- Includes departments with no such projects (LEFT JOIN + date condition
-- kept in the ON clause, NOT the WHERE clause, to avoid the LEFT JOIN trap).
SELECT d.DeptName, p.ProjectName
FROM Department d
LEFT JOIN Project p ON d.DeptID = p.DeptID AND YEAR(p.StartDate) = 2024
ORDER BY d.DeptName;

-- Task B10: Every employee with total weekly hours across all their projects.
-- Includes employees with zero hours (LEFT JOIN + SUM + GROUP BY).
SELECT e.EmpName, COALESCE(SUM(a.HoursPerWeek), 0) AS TotalHours
FROM Employee e
LEFT JOIN Assignment a ON e.EmpID = a.EmpID
GROUP BY e.EmpID, e.EmpName
ORDER BY e.EmpName;

-- ============================================================
-- END OF LAB 8
-- ============================================================
