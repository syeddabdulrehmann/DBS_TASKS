# Lab 8 — SQL Joins (Company Database)

Solutions for Lab Manual #2, **Lab Tasks Part A and Part B**, run against the `joins_lab` (Company) schema: `Department`, `Employee`, `Project`, `Assignment`.

## Contents
- `RollNo_Lab8_Joins.sql` — database setup script, sample data, and all 20 task answers (A1–A10, B1–B10), each labelled with a comment.

## How to run
1. Open MySQL Workbench or the MySQL command-line client.
2. Run the whole file, or run the setup section first, then each task query one at a time.
3. Rename the file to replace `RollNo` with your actual roll number before submitting.

## Notes on specific tasks
- **B2, B3, B8** are written and verified as logically correct join queries, but return **zero rows** against this particular sample dataset — no employee currently out-earns their manager, no employee's manager sits in a different department, and no employee works on a project outside their own department. That is the correct, expected result for this data, not a bug.
- **B9** deliberately keeps the `YEAR(p.StartDate) = 2024` condition inside the `ON` clause (not `WHERE`) to avoid silently turning the `LEFT JOIN` into an `INNER JOIN`, per the manual's "LEFT JOIN + WHERE trap" warning.
- All queries were sanity-checked against the exact sample data from the manual before being finalized.

## Submission
Per the lab manual's instructions, push this folder as `Lab2-Joins/` (or your course's expected folder name) to your GitHub repository, with the `.sql` file renamed to your roll number.
