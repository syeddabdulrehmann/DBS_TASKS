-- =====================================================================
-- DATABASE SYSTEMS | ASSESSMENT PROBLEM SOLUTION
-- Topic     : Database Normalization (1NF -> 2NF -> 3NF)
-- Scenario  : Hospital Patient Visits (Section 8 of the Lab Manual)
-- Student   : RollNo_YourName   (rename this file before submitting)
-- Folder    : Lab-Normalization/
-- =====================================================================

DROP DATABASE IF EXISTS hospital_lab;
CREATE DATABASE hospital_lab;
USE hospital_lab;

-- =====================================================================
-- DELIVERABLE 1 — Functional Dependencies & Candidate Key
-- =====================================================================
-- Raw (unnormalized) columns:
--   VisitID, VisitDate, PatientID, PatientName, PatientPhone,
--   DoctorID, DoctorName, Specialty, DeptName, DeptHead,
--   Diagnosis, Fee
--
-- Functional Dependencies (FDs):
--   VisitID    -> VisitDate, PatientID, DoctorID, Diagnosis, Fee
--   PatientID  -> PatientName, PatientPhone
--   DoctorID   -> DoctorName, Specialty, DeptName
--   DeptName   -> DeptHead
--
-- Candidate key: VisitID
--   (unlike the class example, each row here already represents exactly
--    one visit, so a single attribute — VisitID — is enough to uniquely
--    identify every row; no composite key is required.)

-- =====================================================================
-- DELIVERABLE 2 — First Normal Form (1NF)
-- =====================================================================
-- Rule: atomic values only, no repeating groups, uniquely identifiable rows.
-- Table 8.1 already contains only atomic cells (it was only shown split
-- across three views for layout reasons), so 1NF simply merges those
-- three views into a single relation keyed on VisitID.

CREATE TABLE Visit_1NF (
    VisitID       VARCHAR(10) PRIMARY KEY,
    VisitDate     DATE,
    PatientID     VARCHAR(10),
    PatientName   VARCHAR(50),
    PatientPhone  VARCHAR(20),
    DoctorID      VARCHAR(10),
    DoctorName    VARCHAR(50),
    Specialty     VARCHAR(50),
    DeptName      VARCHAR(50),
    DeptHead      VARCHAR(50),
    Diagnosis     VARCHAR(100),
    Fee           DECIMAL(10,2)
);

INSERT INTO Visit_1NF VALUES
('V-9001','2026-04-10','P-201','Hassan','0300-1112233','D-30','Dr. Imran','Cardiology','Heart Care','Dr. Tariq','Hypertension',2500),
('V-9002','2026-04-10','P-202','Mehreen','0301-4445566','D-31','Dr. Asma','Dermatology','Skin Clinic','Dr. Asma','Eczema',2000),
('V-9003','2026-04-11','P-201','Hassan','0300-1112233','D-31','Dr. Asma','Dermatology','Skin Clinic','Dr. Asma','Allergy',2000),
('V-9004','2026-04-12','P-203','Junaid','0302-7778899','D-30','Dr. Imran','Cardiology','Heart Care','Dr. Tariq','Arrhythmia',3000);

-- Still redundant: patient, doctor and department facts repeat across
-- visits (e.g. Hassan's name/phone repeat in V-9001 and V-9003; Dr.
-- Imran's/Heart Care's details repeat in V-9001 and V-9004).

-- =====================================================================
-- DELIVERABLE 3 — Second Normal Form (2NF)
-- =====================================================================
-- Rule: table is in 1NF and every non-prime attribute depends on the
-- WHOLE primary key — no partial dependencies.
--
-- Justification: a partial dependency can only exist when the primary
-- key is COMPOSITE (made of more than one column). Here the candidate
-- key is the single attribute VisitID, so by definition no non-prime
-- attribute can depend on "part of" the key — every attribute either
-- depends on the whole key (VisitID) or it doesn't depend on it at all.
-- Therefore Visit_1NF already satisfies 2NF with no decomposition
-- required at this stage; we simply carry it forward as Visit_2NF.
--
-- (Transitive dependencies such as VisitID -> PatientID -> PatientName
-- do exist, but those are a 3NF concern, not a 2NF/partial-dependency one.)

CREATE TABLE Visit_2NF (
    VisitID       VARCHAR(10) PRIMARY KEY,
    VisitDate     DATE,
    PatientID     VARCHAR(10),
    PatientName   VARCHAR(50),
    PatientPhone  VARCHAR(20),
    DoctorID      VARCHAR(10),
    DoctorName    VARCHAR(50),
    Specialty     VARCHAR(50),
    DeptName      VARCHAR(50),
    DeptHead      VARCHAR(50),
    Diagnosis     VARCHAR(100),
    Fee           DECIMAL(10,2)
);

INSERT INTO Visit_2NF SELECT * FROM Visit_1NF;

DROP TABLE IF EXISTS Visit_1NF;

-- =====================================================================
-- DELIVERABLE 4 — Third Normal Form (3NF)
-- =====================================================================
-- Rule: table is in 2NF and no non-prime attribute is transitively
-- dependent on the primary key.
--
-- Transitive dependencies found in Visit_2NF:
--   VisitID -> PatientID -> PatientName, PatientPhone
--   VisitID -> DoctorID  -> DoctorName, Specialty, DeptName
--   DoctorID -> DeptName -> DeptHead   (a second-level transitive chain)
--
-- Fix: extract Patient, Department and Doctor into their own tables,
-- leaving Visit holding only facts that truly depend on VisitID itself
-- (VisitDate, Diagnosis, Fee) plus foreign keys to the patient and doctor
-- who were involved.

DROP TABLE IF EXISTS Visit_2NF;

CREATE TABLE Patient (
    PatientID     VARCHAR(10) PRIMARY KEY,
    PatientName   VARCHAR(50),
    PatientPhone  VARCHAR(20)
);

CREATE TABLE Department (
    DeptName      VARCHAR(50) PRIMARY KEY,
    DeptHead      VARCHAR(50)
);

CREATE TABLE Doctor (
    DoctorID      VARCHAR(10) PRIMARY KEY,
    DoctorName    VARCHAR(50),
    Specialty     VARCHAR(50),
    DeptName      VARCHAR(50),
    FOREIGN KEY (DeptName) REFERENCES Department(DeptName)
);

CREATE TABLE Visit (
    VisitID       VARCHAR(10) PRIMARY KEY,
    VisitDate     DATE,
    PatientID     VARCHAR(10),
    DoctorID      VARCHAR(10),
    Diagnosis     VARCHAR(100),
    Fee           DECIMAL(10,2),
    FOREIGN KEY (PatientID) REFERENCES Patient(PatientID),
    FOREIGN KEY (DoctorID)  REFERENCES Doctor(DoctorID)
);

-- Populate the final 3NF schema
INSERT INTO Department VALUES
('Heart Care','Dr. Tariq'),
('Skin Clinic','Dr. Asma');

INSERT INTO Doctor VALUES
('D-30','Dr. Imran','Cardiology','Heart Care'),
('D-31','Dr. Asma','Dermatology','Skin Clinic');

INSERT INTO Patient VALUES
('P-201','Hassan','0300-1112233'),
('P-202','Mehreen','0301-4445566'),
('P-203','Junaid','0302-7778899');

INSERT INTO Visit VALUES
('V-9001','2026-04-10','P-201','D-30','Hypertension',2500),
('V-9002','2026-04-10','P-202','D-31','Eczema',2000),
('V-9003','2026-04-11','P-201','D-31','Allergy',2000),
('V-9004','2026-04-12','P-203','D-30','Arrhythmia',3000);

-- =====================================================================
-- DELIVERABLE 5 — Verification Query (recreates Table 8.1)
-- =====================================================================

SELECT
    v.VisitID,
    v.VisitDate,
    p.PatientID,
    p.PatientName,
    p.PatientPhone,
    d.DoctorID,
    d.DoctorName,
    d.Specialty,
    d.DeptName,
    dept.DeptHead,
    v.Diagnosis,
    v.Fee
FROM Visit v
JOIN Patient    p    ON v.PatientID = p.PatientID
JOIN Doctor     d    ON v.DoctorID  = d.DoctorID
JOIN Department dept ON d.DeptName  = dept.DeptName
ORDER BY v.VisitID;

-- =====================================================================
-- DELIVERABLE 6 — Anomalies Eliminated by This Design
-- =====================================================================
-- INSERTION: A new doctor (or department, or patient) can now be added
--   directly to the Doctor/Department/Patient table with no visit
--   required — previously a doctor couldn't exist until a patient saw
--   them.
-- UPDATE: If Dr. Imran's specialty or department head changes, it is a
--   single-row UPDATE in Doctor/Department instead of touching every
--   visit row that mentions him (previously V-9001 AND V-9004 would
--   both need editing).
-- DELETION: Deleting visit V-9002 (Mehreen's only recorded visit) no
--   longer erases Mehreen's patient record, and it no longer erases
--   Dr. Asma's or the Skin Clinic's details, because those now live in
--   their own tables independent of any single visit.
-- Overall, every fact — patient, doctor, department, and visit-specific
-- data (date, diagnosis, fee) — is stored in exactly one place, and
-- foreign keys (Visit->Patient, Visit->Doctor, Doctor->Department) keep
-- everything consistent.
-- =====================================================================
-- End of Assessment Problem Solution (Hospital Normalization)
-- =====================================================================
