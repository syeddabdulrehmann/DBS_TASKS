# Lab 10 — String Functions

**Course:** Database Systems
**Topic:** Scalar SQL string functions (`TRIM`, `UPPER`/`LOWER`, `CONCAT`, `SUBSTRING`, `LEFT`/`RIGHT`, `REPLACE`, `LPAD`, `LOCATE`, etc.)
**Tools:** MySQL 8.x, MySQL Workbench / Command Line Client

## Contents

- `RollNo_Lab10_StringFunctions.sql` — self-contained script:
  - Database/table setup (`scalar_lab.Customer`, `scalar_lab.Product`) with sample data
  - Solutions to Tasks A1–A12 (Part A — String Functions), each labelled with a `-- Task AX` comment

## How to run

1. Open the `.sql` file in MySQL Workbench or the MySQL CLI.
2. Rename the file to replace `RollNo` with your actual roll number.
3. Execute the whole script — it creates the `scalar_lab` database and both tables, then runs every task query in order.

## Submission

Push this folder to your GitHub repository as `Lab10-StringFunctions/`, containing the renamed `.sql` file.
