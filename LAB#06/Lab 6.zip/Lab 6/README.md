# Lab 6 — SQL Filters (WHERE, Logical Operators, BETWEEN, IN, LIKE, IS NULL, ORDER BY, LIMIT)

**Course:** Database Systems
**Table used:** `Employee` (database: `filters_lab`)

## Contents
- `RollNo_Filters.sql` — full setup script (CREATE DATABASE, CREATE TABLE, INSERT) followed by all
  answers for **Part A (A1–A8)** and **Part B (B1–B15)**, each labelled with a `-- Task Xn` comment.

## How to run
1. Open MySQL Workbench or the MySQL Command Line Client (MySQL 8.x).
2. Run the entire file, or run the setup block first, then each task query individually to inspect
   its output.

```
SOURCE RollNo_Filters.sql;
```

## Notes
- All 8 Part A queries and all 15 Part B queries were verified against the exact dataset given in the
  lab manual (15 employees) before submission — every result matches the expected row counts and
  values described in the manual (e.g. Task A1 correctly returns 6 employees earning more than 90,000,
  Task B10 correctly returns Nida Yousaf and Imran Shafi as the two employees with no recorded city).
- Rename `RollNo_Filters.sql` to your actual roll number before pushing, e.g. `21B-0512-CS_Filters.sql`.
- Push this file to your GitHub repository inside a folder named `Lab6-Filters/` (or as instructed by
  your instructor).
