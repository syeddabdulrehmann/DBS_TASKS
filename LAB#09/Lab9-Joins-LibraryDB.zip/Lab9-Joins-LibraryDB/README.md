# Lab 9 — SQL Joins Assessment (Library Database)

Solutions for Lab Manual #2's graded **Assessment Problem**, run against the `library_lab` schema: `Author`, `Book`, `Member`, `Loan`.

## Contents
- `RollNo_Lab9_Joins.sql` — database setup script, sample data, and all 10 assessment answers (Q1–Q10), each labelled with a comment and its mark weight.

## How to run
1. Open MySQL Workbench or the MySQL command-line client.
2. Run the whole file, or run the setup section first, then each question's query one at a time.
3. Rename the file to replace `RollNo` with your actual roll number before submitting.

## Notes on specific questions
- **Q4** joins across all four tables (`Loan`, `Member`, `Book`, `Author`) since the author's name is required alongside the loan, member, and book details.
- **Q6** filters on `a.Country = 'Pakistan'`, which is safe to place in `WHERE` on a `LEFT JOIN` because the condition is on the *left* table's own column, not the joined table — it will not silently drop unmatched rows the way a right-table condition would.
- **Q8** uses `LEFT JOIN` + `GROUP BY` + `HAVING COUNT(...) = 0` to correctly find authors where *every one* of their books has zero loans (verified: only Bapsi Sidhwa, whose book "Ice-Candy-Man" has never been borrowed).
- All queries were sanity-checked against the exact sample data from the manual before being finalized.

## Submission
Per the lab manual's instructions, push this folder to your GitHub repository, with the `.sql` file renamed to your roll number, and share the link before the deadline.
