-- ============================================================
-- LAB 9 — SQL JOINS ASSESSMENT (Library Database)
-- Database Systems
-- Student: RollNo (replace with your actual roll number)
-- Covers: Lab Manual #2 - Assessment Problem (Library Database)
-- Engine: MySQL 8.x
-- ============================================================

-- ============================================================
-- SECTION 1: SETUP SCRIPT (run first)
-- ============================================================

CREATE DATABASE IF NOT EXISTS library_lab;
USE library_lab;

DROP TABLE IF EXISTS Loan, Book, Member, Author;

CREATE TABLE Author (
    AuthorID   INT PRIMARY KEY,
    AuthorName VARCHAR(60) NOT NULL,
    Country    VARCHAR(30)
);

CREATE TABLE Book (
    BookID        INT PRIMARY KEY,
    Title         VARCHAR(80) NOT NULL,
    Genre         VARCHAR(30),
    Price         DECIMAL(8,2),
    AuthorID      INT,
    PublishedYear INT,
    FOREIGN KEY (AuthorID) REFERENCES Author(AuthorID)
);

CREATE TABLE Member (
    MemberID   INT PRIMARY KEY,
    MemberName VARCHAR(60) NOT NULL,
    City       VARCHAR(30),
    JoinDate   DATE
);

CREATE TABLE Loan (
    LoanID     INT PRIMARY KEY,
    MemberID   INT,
    BookID     INT,
    LoanDate   DATE,
    ReturnDate DATE, -- NULL = not yet returned
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID),
    FOREIGN KEY (BookID) REFERENCES Book(BookID)
);

INSERT INTO Author VALUES
(1,'Jane Austen',      'UK'),
(2,'Chinua Achebe',    'Nigeria'),
(3,'Haruki Murakami',  'Japan'),
(4,'Bapsi Sidhwa',     'Pakistan'),
(5,'Mohsin Hamid',     'Pakistan'),
(6,'Anonymous Writer', NULL); -- no books

INSERT INTO Book VALUES
(101,'Pride and Prejudice',         'Fiction',  850.00, 1, 1813),
(102,'Emma',                        'Fiction',  900.00, 1, 1815),
(103,'Things Fall Apart',           'Fiction', 1100.00, 2, 1958),
(104,'Norwegian Wood',              'Fiction', 1500.00, 3, 1987),
(105,'Kafka on the Shore',          'Fiction', 1700.00, 3, 2002),
(106,'Ice-Candy-Man',               'Fiction', 1200.00, 4, 1988),
(107,'The Reluctant Fundamentalist','Fiction', 1300.00, 5, 2007),
(108,'Exit West',                   'Fiction', 1450.00, 5, 2017),
(109,'Mystery Title',               'Mystery',  950.00, NULL, 2020); -- no author

INSERT INTO Member VALUES
(201,'Ahmad Raza',  'Lahore',    '2023-01-15'),
(202,'Sara Imran',  'Karachi',   '2023-03-20'),
(203,'Bilal Khan',  'Lahore',    '2024-02-10'),
(204,'Fatima Ali',  'Islamabad', '2022-09-05'),
(205,'Hira Yousaf', NULL,        '2024-05-01'); -- no loans yet

INSERT INTO Loan VALUES
(1, 201, 101, '2024-03-01', '2024-03-15'),
(2, 201, 104, '2024-04-10', NULL),
(3, 202, 103, '2024-02-20', '2024-03-05'),
(4, 202, 107, '2024-05-01', NULL),
(5, 203, 105, '2024-04-25', '2024-05-15'),
(6, 204, 102, '2024-01-10', '2024-01-30'),
(7, 204, 108, '2024-06-01', NULL);


-- ============================================================
-- SECTION 2: ASSESSMENT ANSWERS (Q1 - Q10)
-- ============================================================

-- Q1 (10 marks): Every book with its author's name and country (INNER JOIN)
SELECT b.Title, a.AuthorName, a.Country
FROM Book b
INNER JOIN Author a ON b.AuthorID = a.AuthorID;

-- Q2 (10 marks): Every author with their books.
-- Authors with no books still appear once with NULL Title (LEFT JOIN)
SELECT a.AuthorName, b.Title
FROM Author a
LEFT JOIN Book b ON a.AuthorID = b.AuthorID
ORDER BY a.AuthorName;

-- Q3 (10 marks): Members who have never borrowed any book (LEFT JOIN + IS NULL)
SELECT m.MemberID, m.MemberName
FROM Member m
LEFT JOIN Loan l ON m.MemberID = l.MemberID
WHERE l.MemberID IS NULL;

-- Q4 (15 marks): Every loan with member's name, book title, and author's name
-- (join across Loan, Member, Book, and Author)
SELECT l.LoanID, m.MemberName, b.Title, a.AuthorName
FROM Loan l
JOIN Member m ON l.MemberID = m.MemberID
JOIN Book b ON l.BookID = b.BookID
JOIN Author a ON b.AuthorID = a.AuthorID;

-- Q5 (10 marks): Currently borrowed books (ReturnDate IS NULL) with borrower's
-- name and city
SELECT b.Title, m.MemberName, m.City
FROM Loan l
JOIN Member m ON l.MemberID = m.MemberID
JOIN Book b ON l.BookID = b.BookID
WHERE l.ReturnDate IS NULL;

-- Q6 (15 marks): Pakistani authors and the titles of their books.
-- Includes Pakistani authors with no books (LEFT JOIN + WHERE on author
-- country — safe here because the filter is on the LEFT table's own column,
-- not the joined/right table).
SELECT a.AuthorName, b.Title
FROM Author a
LEFT JOIN Book b ON a.AuthorID = b.AuthorID
WHERE a.Country = 'Pakistan';

-- Q7 (10 marks): Every book with the names of all members who have borrowed
-- it. Includes books that have never been borrowed (LEFT JOIN chain).
SELECT b.Title, m.MemberName
FROM Book b
LEFT JOIN Loan l ON b.BookID = l.BookID
LEFT JOIN Member m ON l.MemberID = m.MemberID
ORDER BY b.Title;

-- Q8 (10 marks): Authors whose books have never been borrowed
-- (Author -> Book -> Loan, using LEFT JOIN + GROUP BY + HAVING to catch
-- authors where every one of their books has zero loans)
SELECT a.AuthorName
FROM Author a
JOIN Book b ON a.AuthorID = b.AuthorID
LEFT JOIN Loan l ON b.BookID = l.BookID
GROUP BY a.AuthorID, a.AuthorName
HAVING COUNT(l.LoanID) = 0;

-- Q9 (5 marks): FULL OUTER JOIN of Author and Book, emulated with UNION
-- (every author and every book, matched where possible)
SELECT a.AuthorName, b.Title
FROM Author a
LEFT JOIN Book b ON a.AuthorID = b.AuthorID
UNION
SELECT a.AuthorName, b.Title
FROM Author a
RIGHT JOIN Book b ON a.AuthorID = b.AuthorID;

-- Q10 (5 marks): Members who have borrowed books written by Pakistani
-- authors. Show member name, book title, and author name (4-way join
-- with filter).
SELECT DISTINCT m.MemberName, b.Title, a.AuthorName
FROM Loan l
JOIN Member m ON l.MemberID = m.MemberID
JOIN Book b ON l.BookID = b.BookID
JOIN Author a ON b.AuthorID = a.AuthorID
WHERE a.Country = 'Pakistan';

-- ============================================================
-- END OF LAB 9
-- ============================================================
